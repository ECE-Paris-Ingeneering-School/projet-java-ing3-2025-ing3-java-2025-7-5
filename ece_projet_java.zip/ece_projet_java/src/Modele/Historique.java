package Modele;

public class Historique {
    private int id;
    private int patientId;
    private int rendezVousId;
    private String notes;

    public Historique(int id, int patientId, int rendezVousId, String notes) {
        this.id = id;
        this.patientId = patientId;
        this.rendezVousId = rendezVousId;
        this.notes = notes;
    }

    public int getId() { return id; }
    public int getPatientId() { return patientId; }
    public int getRendezVousId() { return rendezVousId; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
