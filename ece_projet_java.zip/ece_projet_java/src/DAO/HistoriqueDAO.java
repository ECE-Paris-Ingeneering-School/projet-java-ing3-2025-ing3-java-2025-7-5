package DAO;

import Modele.Historique;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HistoriqueDAO {
    public static void ajouterNote(int patientId, int rendezVousId, String notes) throws DAOException {
        try (Connection conn = DBConnection.getConnection()) {
            // Vérifier si une ligne existe déjà pour ce rendez-vous
            PreparedStatement check = conn.prepareStatement("SELECT id FROM HISTORIQUE WHERE rendez_vous_id = ?");
            check.setInt(1, rendezVousId);
            ResultSet rs = check.executeQuery();
            if (rs.next()) {
                // Si existe, faire un UPDATE
                int histoId = rs.getInt("id");
                PreparedStatement update = conn.prepareStatement("UPDATE HISTORIQUE SET notes = ? WHERE id = ?");
                update.setString(1, notes);
                update.setInt(2, histoId);
                update.executeUpdate();
            } else {
                // Sinon, faire un INSERT
                PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO HISTORIQUE(patient_id, rendez_vous_id, notes) VALUES (?, ?, ?)");
                ps.setInt(1, patientId);
                ps.setInt(2, rendezVousId);
                ps.setString(3, notes);
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            throw new DAOException("Erreur HistoriqueDAO.ajouterNote: " + e.getMessage(), e);
        }
    }

    public static List<Historique> getHistoriquesByPatient(int patientId) throws DAOException {
        List<Historique> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT id, patient_id, rendez_vous_id, notes FROM HISTORIQUE WHERE patient_id = ?");
            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Historique(
                    rs.getInt("id"),
                    rs.getInt("patient_id"),
                    rs.getInt("rendez_vous_id"),
                    rs.getString("notes")
                ));
            }
        } catch (SQLException e) {
            throw new DAOException("Erreur HistoriqueDAO.getHistoriquesByPatient: " + e.getMessage(), e);
        }
        return list;
    }

    public static Historique getHistoriqueByRendezVous(int rendezVousId) throws DAOException {
        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT id, patient_id, rendez_vous_id, notes FROM HISTORIQUE WHERE rendez_vous_id = ?");
            ps.setInt(1, rendezVousId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Historique(
                    rs.getInt("id"),
                    rs.getInt("patient_id"),
                    rs.getInt("rendez_vous_id"),
                    rs.getString("notes")
                );
            }
        } catch (SQLException e) {
            throw new DAOException("Erreur HistoriqueDAO.getHistoriqueByRendezVous: " + e.getMessage(), e);
        }
        return null;
    }

    public static List<Historique> getAllHistoriques() throws DAOException {
        List<Historique> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT id, patient_id, rendez_vous_id, notes FROM HISTORIQUE");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Historique(
                    rs.getInt("id"),
                    rs.getInt("patient_id"),
                    rs.getInt("rendez_vous_id"),
                    rs.getString("notes")
                ));
            }
        } catch (SQLException e) {
            throw new DAOException("Erreur getAllHistoriques: " + e.getMessage(), e);
        }
        return list;
    }

    public static void updateHistorique(int id, String colName, Object value) throws DAOException {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE HISTORIQUE SET " + colName + " = ? WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setObject(1, value);
                ps.setInt(2, id);
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            throw new DAOException("Erreur updateHistorique: " + e.getMessage(), e);
        }
    }
}
