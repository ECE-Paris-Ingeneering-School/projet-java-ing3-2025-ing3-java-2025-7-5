package Vue;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DAO.DBConnection;
import DAO.DAOException;
import java.text.ParseException;
import java.util.Vector;
import Modele.Patient;
import DAO.RendezVousDAO;
import Modele.RendezVous;
import java.util.List;
import Controleur.PatientControleur;

public class DashboardPatientPanel extends JPanel {
    private MainFrame frame;
    private Patient patient;
    private PatientControleur controleur;
    private JTabbedPane tabbedPane = new JTabbedPane();
    private JTable rdvTable;
    private JLabel prochainRdvLabel = new JLabel();

    public DashboardPatientPanel(MainFrame frame, Patient patient) {
        this.frame = frame;
        this.patient = patient;
        this.controleur = new Controleur.PatientControleur(patient);
        setLayout(new BorderLayout());
        add(buildHeaderPanel(), BorderLayout.NORTH);
        tabbedPane.addTab("Tableau de bord", buildDashboardTab());
        tabbedPane.addTab("Rendez-vous", buildRdvTab());
        add(tabbedPane, BorderLayout.CENTER);
    }

    private JPanel buildHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        JPanel infos = new JPanel(new GridLayout(3,2));
        infos.add(new JLabel(patient.getNom() + " " + patient.getPrenom()));
        infos.add(new JLabel("Né(e) le " + formatDate(patient.getDateNaissance())));
        infos.add(new JLabel(patient.getEmail()));
        infos.add(new JLabel(patient.getTelephone()));
        infos.add(new JLabel("Adresse: "+patient.getAdresse()));
        header.add(infos, BorderLayout.WEST);
        JPanel actions = new JPanel(new GridLayout(2,1,5,5));
        JButton btnDeconnexion = new JButton("Déconnexion");
        btnDeconnexion.addActionListener(e -> frame.showPanel("accueil"));
        JButton btnModifier = new JButton("Modifier le profil");
        btnModifier.addActionListener(e -> showModifierProfilDialog());
        actions.add(btnDeconnexion);
        actions.add(btnModifier);
        header.add(actions, BorderLayout.EAST);
        return header;
    }

    private String formatDate(String dateIso) {
        if (dateIso == null || dateIso.length() != 10) return "";
        String[] parts = dateIso.split("-");
        if (parts.length == 3) return parts[2]+"/"+parts[1]+"/"+parts[0];
        return dateIso;
    }

    private JPanel buildDashboardTab() {
        JPanel panel = new JPanel(new BorderLayout());
        // Prochain rendez-vous
        JPanel prochainPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        prochainPanel.add(new JLabel("Prochain rendez-vous : "));
        prochainPanel.add(prochainRdvLabel);
        panel.add(prochainPanel, BorderLayout.NORTH);
        // Actions rapides
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnPrendreRdv = new JButton("Prendre un RDV");
        JButton btnHistorique = new JButton("Mon historique");
        actions.add(btnPrendreRdv);
        actions.add(btnHistorique);
        panel.add(actions, BorderLayout.CENTER);
        btnPrendreRdv.addActionListener(e -> showRechercheRdvDialog());
        btnHistorique.addActionListener(e -> showHistoriqueDialog());
        chargerProchainRdv();
        return panel;
    }

    private JPanel buildRdvTab() {
        JPanel panel = new JPanel(new BorderLayout());
        // Table des rendez-vous
        String[] columns = {"Spécialiste", "Spécialité", "Date", "Statut", "Note", "Action"};
        Vector<Vector<Object>> data = chargerRendezVous();
        rdvTable = new JTable(new javax.swing.table.DefaultTableModel(data, new Vector<>(java.util.List.of(columns))) {
            public boolean isCellEditable(int row, int col) { return col == 5; }
        });
        rdvTable.getColumn("Action").setCellRenderer(new ButtonRenderer());
        rdvTable.getColumn("Action").setCellEditor(new ButtonEditor(new JCheckBox(), this));
        JScrollPane scroll = new JScrollPane(rdvTable);
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    private void showModifierProfilDialog() {
        JTextField nomField = new JTextField(patient.getNom(), 15);
        JTextField prenomField = new JTextField(patient.getPrenom(), 15);
        JFormattedTextField dateField;
        try {
            MaskFormatter dateFormatter = new MaskFormatter("##/##/####");
            dateFormatter.setPlaceholderCharacter('_');
            dateField = new JFormattedTextField(dateFormatter);
            dateField.setColumns(10);
            dateField.setText(formatDate(patient.getDateNaissance()));
        } catch (ParseException ex) {
            dateField = new JFormattedTextField();
            dateField.setText(formatDate(patient.getDateNaissance()));
        }
        JTextField emailField = new JTextField(patient.getEmail(), 15);
        JTextField adresseField = new JTextField(patient.getAdresse(), 20);
        JTextField telField = new JTextField(patient.getTelephone(), 15);
        JPasswordField mdpField = new JPasswordField(15);
        JPasswordField mdpConfirmField = new JPasswordField(15);
        JPanel panel = new JPanel(new GridLayout(8,2));
        panel.add(new JLabel("Nom:")); panel.add(nomField);
        panel.add(new JLabel("Prénom:")); panel.add(prenomField);
        panel.add(new JLabel("Date de naissance (JJ/MM/AAAA):")); panel.add(dateField);
        panel.add(new JLabel("Email:")); panel.add(emailField);
        panel.add(new JLabel("Adresse:")); panel.add(adresseField);
        panel.add(new JLabel("Téléphone:")); panel.add(telField);
        panel.add(new JLabel("Nouveau mot de passe:")); panel.add(mdpField);
        panel.add(new JLabel("Confirmer mot de passe:")); panel.add(mdpConfirmField);
        int res = JOptionPane.showConfirmDialog(this, panel, "Modifier le profil", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (res == JOptionPane.OK_OPTION) {
            patient.setNom(nomField.getText().trim());
            patient.setPrenom(prenomField.getText().trim());
            String dateN = dateField.getText().trim();
            String[] parts = dateN.split("/");
            if (parts.length == 3) patient.setDateNaissance(parts[2] + "-" + parts[1] + "-" + parts[0]);
            patient.setEmail(emailField.getText().trim());
            patient.setAdresse(adresseField.getText().trim());
            patient.setTelephone(telField.getText().trim());
            String mdp = new String(mdpField.getPassword());
            String mdpConfirm = new String(mdpConfirmField.getPassword());
            if (!mdp.isEmpty() || !mdpConfirm.isEmpty()) {
                if (!mdp.equals(mdpConfirm)) {
                    JOptionPane.showMessageDialog(this, "Les mots de passe ne correspondent pas.");
                    return;
                }
                patient.setMotDePasse(mdp);
            }
            try {
                controleur.updateProfil(patient);
                JOptionPane.showMessageDialog(this, "Profil mis à jour.");
                removeAll();
                add(buildHeaderPanel(), BorderLayout.NORTH);
                add(tabbedPane, BorderLayout.CENTER);
                revalidate();
                repaint();
            } catch (DAO.DAOException ex) {
                JOptionPane.showMessageDialog(this, "Erreur lors de la mise à jour: " + ex.getMessage());
            }
        }
    }

    private void chargerProchainRdv() {
        try {
            RendezVous prochain = controleur.getProchainRendezVous();
            if (prochain != null) {
                String spec = prochain.getSpecialisteNom() + " " + prochain.getSpecialistePrenom();
                String date = prochain.getDateHeure();
                String specialite = prochain.getSpecialisation();
                prochainRdvLabel.setText("Prochain rendez-vous : " + date + " avec " + spec + " (" + specialite + ")");
            } else {
                prochainRdvLabel.setText("Aucun prochain rendez-vous");
            }
        } catch (DAO.DAOException e) {
            prochainRdvLabel.setText("Erreur de chargement");
        }
    }

    private Vector<Vector<Object>> chargerRendezVous() {
        Vector<Vector<Object>> data = new Vector<>();
        try {
            List<RendezVous> rdvs = controleur.getRendezVous();
            for (RendezVous rdv : rdvs) {
                Vector<Object> row = new Vector<>();
                row.add(rdv.getSpecialisteNom() + " " + rdv.getSpecialistePrenom());
                row.add(rdv.getSpecialisation());
                row.add(rdv.getDateHeure());
                String statut = rdv.getStatut();
                row.add(statut);
                // Ajout de la note du spécialiste
                String note = "";
                try {
                    Modele.Historique histo = controleur.getHistoriqueByRendezVous(rdv.getId());
                    if (histo != null) note = histo.getNotes();
                } catch (Exception e) { note = ""; }
                row.add(note);
                if ("confirmé".equals(statut)) {
                    row.add("Annuler");
                } else {
                    row.add("");
                }
                row.add(rdv.getId()); // id caché pour action
                data.add(row);
            }
        } catch (DAO.DAOException e) {
            // rien
        }
        return data;
    }

    // Renderer et Editor pour bouton dans JTable
    class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
        public ButtonRenderer() { setOpaque(true); }
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;
        private boolean isPushed;
        private DashboardPatientPanel parent;
        private int row;
        public ButtonEditor(JCheckBox checkBox, DashboardPatientPanel parent) {
            super(checkBox);
            this.parent = parent;
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
        }
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.row = row;
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            isPushed = true;
            return button;
        }
        public Object getCellEditorValue() {
            if (isPushed && "Annuler".equals(label)) {
                try {
                    int modelRow = parent.rdvTable.convertRowIndexToModel(row);
                    List<RendezVous> rdvs = parent.controleur.getRendezVous();
                    if (modelRow < rdvs.size()) {
                        int idRdv = rdvs.get(modelRow).getId();
                        annulerRdv(idRdv);
                    } else {
                        JOptionPane.showMessageDialog(parent, "Impossible d'identifier le rendez-vous à annuler.");
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(parent, "Erreur lors de l'annulation du rendez-vous.");
                }
            }
            isPushed = false;
            return label;
        }
    }
    private void annulerRdv(int idRdv) {
        try {
            controleur.annulerRendezVous(idRdv);
            DAO.RendezVousDAO.remettreCreneauLibre(idRdv); // Remet le créneau en libre
            JOptionPane.showMessageDialog(this, "Rendez-vous annulé et créneau remis en libre.");
            tabbedPane.setComponentAt(1, buildRdvTab());
            chargerProchainRdv();
        } catch (DAO.DAOException e) {
            JOptionPane.showMessageDialog(this, "Erreur lors de l'annulation : " + e.getMessage());
        }
    }

    private void showRechercheRdvDialog() {
        JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "Prendre un rendez-vous", true);
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(this);
        JPanel panel = new JPanel(new BorderLayout(10,10));
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Spécialité : "));
        JTextField specialiteField = new JTextField(10);
        searchPanel.add(specialiteField);
        searchPanel.add(new JLabel("Nom : "));
        JTextField nomField = new JTextField(10);
        searchPanel.add(nomField);
        JButton btnSearch = new JButton("Rechercher");
        searchPanel.add(btnSearch);
        panel.add(searchPanel, BorderLayout.NORTH);
        DefaultListModel<Modele.Specialiste> model = new DefaultListModel<>();
        JList<Modele.Specialiste> list = new JList<>(model);
        list.setCellRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList<?> l, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(l, value, index, isSelected, cellHasFocus);
                if (value instanceof Modele.Specialiste) {
                    Modele.Specialiste s = (Modele.Specialiste) value;
                    setText(s.getNom() + " " + s.getPrenom() + " - " + s.getSpecialisation());
                }
                return c;
            }
        });
        JScrollPane scroll = new JScrollPane(list);
        panel.add(scroll, BorderLayout.CENTER);
        JPanel creneauxPanel = new JPanel(new BorderLayout());
        panel.add(creneauxPanel, BorderLayout.SOUTH);
        btnSearch.addActionListener(e -> {
            model.clear();
            try {
                String spec = specialiteField.getText().trim();
                String nom = nomField.getText().trim();
                List<Modele.Specialiste> specs = DAO.SpecialisteDAO.getAllSpecialistes();
                for (Modele.Specialiste s : specs) {
                    boolean ok = true;
                    if (!spec.isEmpty() && !s.getSpecialisation().toLowerCase().contains(spec.toLowerCase())) ok = false;
                    if (!nom.isEmpty() && !s.getNom().toLowerCase().contains(nom.toLowerCase())) ok = false;
                    if (ok) model.addElement(s);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erreur recherche : " + ex.getMessage());
            }
        });
        list.addListSelectionListener(e -> {
            creneauxPanel.removeAll();
            Modele.Specialiste selected = list.getSelectedValue();
            if (selected != null) {
                try {
                    List<Modele.RendezVous> creneaux = DAO.RendezVousDAO.getCreneauxDisponiblesPourSpecialiste(selected.getId());
                    DefaultListModel<Modele.RendezVous> creneauModel = new DefaultListModel<>();
                    for (Modele.RendezVous c : creneaux) {
                        creneauModel.addElement(c);
                    }
                    JList<Modele.RendezVous> creneauList = new JList<>(creneauModel);
                    creneauList.setCellRenderer(new DefaultListCellRenderer() {
                        public Component getListCellRendererComponent(JList<?> l, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                            Component c = super.getListCellRendererComponent(l, value, index, isSelected, cellHasFocus);
                            if (value instanceof Modele.RendezVous) {
                                Modele.RendezVous rdv = (Modele.RendezVous) value;
                                setText(rdv.getDateHeure() + " - " + rdv.getSpecialisation());
                            }
                            return c;
                        }
                    });
                    creneauList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                    JScrollPane creneauScroll = new JScrollPane(creneauList);
                    JButton btnReserver = new JButton("Réserver ce créneau");
                    btnReserver.addActionListener(ev -> {
                        Modele.RendezVous rdv = creneauList.getSelectedValue();
                        if (rdv == null) {
                            JOptionPane.showMessageDialog(dialog, "Sélectionnez un créneau.");
                            return;
                        }
                        try {
                            DAO.RendezVousDAO.reserverCreneau(rdv.getId(), patient.getId());
                            JOptionPane.showMessageDialog(dialog, "Créneau réservé !");
                            dialog.dispose();
                            tabbedPane.setComponentAt(1, buildRdvTab());
                            chargerProchainRdv();
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(dialog, "Erreur réservation : " + ex.getMessage());
                        }
                    });
                    JPanel p = new JPanel(new BorderLayout());
                    p.add(creneauScroll, BorderLayout.CENTER);
                    p.add(btnReserver, BorderLayout.SOUTH);
                    creneauxPanel.add(p, BorderLayout.CENTER);
                    creneauxPanel.revalidate();
                    creneauxPanel.repaint();
                } catch (Exception ex) {
                    creneauxPanel.add(new JLabel("Erreur chargement créneaux."), BorderLayout.CENTER);
                }
            }
            creneauxPanel.revalidate();
            creneauxPanel.repaint();
        });
        dialog.setContentPane(panel);
        dialog.setVisible(true);
    }

    private void showHistoriqueDialog() {
        JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "Mon historique", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        JPanel panel = new JPanel(new BorderLayout());
        DefaultListModel<Modele.Historique> model = new DefaultListModel<>();
        JList<Modele.Historique> list = new JList<>(model);
        try {
            List<Modele.Historique> histos = DAO.HistoriqueDAO.getHistoriquesByPatient(patient.getId());
            for (Modele.Historique h : histos) model.addElement(h);
        } catch (Exception e) {
            model.addElement(new Modele.Historique(0,0,0,"Erreur de chargement"));
        }
        list.setCellRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList<?> l, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(l, value, index, isSelected, cellHasFocus);
                if (value instanceof Modele.Historique) {
                    Modele.Historique h = (Modele.Historique) value;
                    setText("RDV #"+h.getRendezVousId()+" : "+h.getNotes());
                }
                return c;
            }
        });
        panel.add(new JScrollPane(list), BorderLayout.CENTER);
        dialog.setContentPane(panel);
        dialog.setVisible(true);
    }
}
