package Vue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AccueilPanel extends JPanel {
    public AccueilPanel(MainFrame frame) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;

        JLabel label = new JLabel("Bienvenue sur Doctolib ECE");
        add(label, gbc);

        gbc.gridy++;
        JButton btnInscription = new JButton("S'inscrire");
        btnInscription.addActionListener(e -> frame.showPanel("inscription"));
        add(btnInscription, gbc);

        gbc.gridy++;
        JButton btnConnexion = new JButton("Se connecter");
        btnConnexion.addActionListener(e -> frame.showPanel("connexion"));
        add(btnConnexion, gbc);
    }
}
