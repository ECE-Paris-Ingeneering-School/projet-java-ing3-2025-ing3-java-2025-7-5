package Vue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DAO.DBConnection;
import DAO.DAOException;
import Modele.Patient;
import DAO.PatientDAO;
import Modele.Specialiste;
import DAO.SpecialisteDAO;
import Modele.Utilisateur;

public class ConnexionPanel extends JPanel {
    private JTextField emailField = new JTextField(15);
    private JPasswordField mdpField = new JPasswordField(15);
    private JLabel errorLabel = new JLabel();

    public ConnexionPanel(MainFrame frame) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;

        add(new JLabel("Email:"), gbc); gbc.gridx++;
        add(emailField, gbc); gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("Mot de passe:"), gbc); gbc.gridx++;
        add(mdpField, gbc); gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;
        errorLabel.setForeground(Color.RED);
        add(errorLabel, gbc);
        gbc.gridy++;
        JButton valider = new JButton("Se connecter");
        add(valider, gbc);
        gbc.gridy++;
        JButton retour = new JButton("Retour");
        add(retour, gbc);

        retour.addActionListener(e -> frame.showPanel("accueil"));

        valider.addActionListener((ActionEvent e) -> {
            errorLabel.setText("");
            String email = emailField.getText().trim();
            String mdp = new String(mdpField.getPassword());
            if (email.isEmpty() || mdp.isEmpty()) {
                errorLabel.setText("Veuillez remplir tous les champs.");
                return;
            }
            try {
                Patient patient = PatientDAO.getPatientByEmailAndPassword(email, mdp);
                if (patient != null) {
                    frame.showDashboardPatient(patient);
                    return;
                }
                Specialiste specialiste = SpecialisteDAO.getSpecialisteByEmailAndPassword(email, mdp);
                if (specialiste != null) {
                    frame.showDashboardSpecialiste(specialiste);
                    return;
                }
                Utilisateur admin = getAdminByEmailAndPassword(email, mdp);
                if (admin != null) {
                    frame.showDashboard("admin");
                    return;
                }
                errorLabel.setText("Identifiants invalides.");
            } catch (DAO.DAOException ex) {
                errorLabel.setText("Erreur: " + ex.getMessage());
            }
        });
    }

    private Utilisateur getAdminByEmailAndPassword(String email, String motDePasse) throws DAO.DAOException {
        try (java.sql.Connection conn = DAO.DBConnection.getConnection()) {
            java.sql.PreparedStatement ps = conn.prepareStatement(
                "SELECT id, nom, prenom, email, mot_de_passe, type_utilisateur FROM UTILISATEUR WHERE BINARY email = ? AND type_utilisateur = 'admin'");
            ps.setString(1, email);
            java.sql.ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String mdpBdd = rs.getString("mot_de_passe");
                if (mdpBdd != null && mdpBdd.equals(motDePasse)) {
                    return new Utilisateur(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("email"),
                        rs.getString("mot_de_passe"),
                        rs.getString("type_utilisateur")
                    );
                }
            }
            return null;
        } catch (java.sql.SQLException e) {
            throw new DAO.DAOException("Erreur Admin Connexion: " + e.getMessage(), e);
        }
    }
}
