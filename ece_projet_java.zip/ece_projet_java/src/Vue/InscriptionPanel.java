package Vue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DAO.DBConnection;
import DAO.DAOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import javax.swing.text.MaskFormatter;
import java.text.ParseException;
import Modele.Patient;
import Modele.Specialiste;
import DAO.PatientDAO;
import DAO.SpecialisteDAO;

public class InscriptionPanel extends JPanel {
    private JTextField nomField = new JTextField(15);
    private JTextField prenomField = new JTextField(15);
    private JTextField emailField = new JTextField(15);
    private JPasswordField mdpField = new JPasswordField(15);
    private JPasswordField mdpConfirmField = new JPasswordField(15);
    private JComboBox<String> typeBox = new JComboBox<>(new String[]{"patient", "specialiste"});
    // Champs patient
    private JFormattedTextField dateNaissanceField;
    private JTextField adresseField = new JTextField(20);
    private JTextField telPatientField = new JTextField(15);
    // Champs specialiste
    private JTextField specialisationField = new JTextField(15);
    private JTextField telSpecField = new JTextField(15);
    private JLabel errorLabel = new JLabel();

    public InscriptionPanel(MainFrame frame) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;

        add(new JLabel("Nom:"), gbc); gbc.gridx++;
        add(nomField, gbc); gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("Prénom:"), gbc); gbc.gridx++;
        add(prenomField, gbc); gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("Email:"), gbc); gbc.gridx++;
        add(emailField, gbc); gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("Mot de passe:"), gbc); gbc.gridx++;
        add(mdpField, gbc); gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("Confirmer mot de passe:"), gbc); gbc.gridx++;
        add(mdpConfirmField, gbc); gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("Type d'utilisateur:"), gbc); gbc.gridx++;
        add(typeBox, gbc); gbc.gridx = 0; gbc.gridy++;

        // Champs spécifiques (patient par défaut)
        JPanel patientPanel = new JPanel(new GridLayout(3,2));
        try {
            MaskFormatter dateFormatter = new MaskFormatter("##/##/####");
            dateFormatter.setPlaceholderCharacter('_');
            dateNaissanceField = new JFormattedTextField(dateFormatter);
            dateNaissanceField.setColumns(10);
        } catch (ParseException ex) {
            dateNaissanceField = new JFormattedTextField();
        }
        patientPanel.add(new JLabel("Date de naissance (JJ/MM/AAAA):"));
        patientPanel.add(dateNaissanceField);
        patientPanel.add(new JLabel("Adresse:"));
        patientPanel.add(adresseField);
        patientPanel.add(new JLabel("Téléphone:"));
        patientPanel.add(telPatientField);

        JPanel specPanel = new JPanel(new GridLayout(2,2));
        specPanel.add(new JLabel("Spécialisation:"));
        specPanel.add(specialisationField);
        specPanel.add(new JLabel("Téléphone:"));
        specPanel.add(telSpecField);

        gbc.gridwidth = 2;
        gbc.gridx = 0;
        add(patientPanel, gbc);
        gbc.gridy++;
        add(specPanel, gbc);
        specPanel.setVisible(false);

        typeBox.addActionListener(e -> {
            boolean isPatient = typeBox.getSelectedItem().equals("patient");
            patientPanel.setVisible(isPatient);
            specPanel.setVisible(!isPatient);
        });

        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy++;
        errorLabel.setForeground(Color.RED);
        add(errorLabel, gbc);
        gbc.gridy++;
        JButton valider = new JButton("Valider");
        add(valider, gbc);
        gbc.gridy++;
        JButton retour = new JButton("Retour");
        add(retour, gbc);

        retour.addActionListener(e -> frame.showPanel("accueil"));

        valider.addActionListener((ActionEvent e) -> {
            errorLabel.setText("");
            String nom = nomField.getText().trim();
            String prenom = prenomField.getText().trim();
            String email = emailField.getText().trim();
            String mdp = new String(mdpField.getPassword());
            String mdpConfirm = new String(mdpConfirmField.getPassword());
            String type = (String) typeBox.getSelectedItem();

            if (nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || mdp.isEmpty() || mdpConfirm.isEmpty()) {
                errorLabel.setText("Tous les champs sont obligatoires.");
                return;
            }
            if (!mdp.equals(mdpConfirm)) {
                errorLabel.setText("Les mots de passe ne correspondent pas.");
                return;
            }
            try {
                if (type.equals("patient")) {
                    String dateN = dateNaissanceField.getText().trim();
                    String[] parts = dateN.split("/");
                    if (parts.length != 3) { errorLabel.setText("Date invalide."); return; }
                    String dateIso = parts[2] + "-" + parts[1] + "-" + parts[0];
                    String adresse = adresseField.getText().trim();
                    String tel = telPatientField.getText().trim();
                    if (dateIso.isEmpty() || adresse.isEmpty() || tel.isEmpty()) {
                        errorLabel.setText("Tous les champs patient sont obligatoires.");
                        return;
                    }
                    Patient patient = new Patient(0, nom, prenom, email, mdp, dateIso, adresse, tel);
                    PatientDAO.inscrirePatient(patient);
                    JOptionPane.showMessageDialog(this, "Inscription patient réussie !");
                    frame.showPanel("connexion");
                } else { // specialiste
                    String specialisation = specialisationField.getText().trim();
                    String tel = telSpecField.getText().trim();
                    if (specialisation.isEmpty() || tel.isEmpty()) {
                        errorLabel.setText("Tous les champs spécialiste sont obligatoires.");
                        return;
                    }
                    Specialiste specialiste = new Specialiste(0, nom, prenom, email, mdp, specialisation, tel);
                    SpecialisteDAO.inscrireSpecialiste(specialiste);
                    JOptionPane.showMessageDialog(this, "Inscription spécialiste réussie !");
                    frame.showPanel("connexion");
                }
            } catch (DAO.DAOException ex) {
                errorLabel.setText("Erreur: " + ex.getMessage());
            }
        });
    }
}
