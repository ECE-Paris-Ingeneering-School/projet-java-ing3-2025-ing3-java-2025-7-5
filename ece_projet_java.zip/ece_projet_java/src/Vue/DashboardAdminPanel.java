package Vue;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;
import java.util.List;
import DAO.*;
import Modele.*;

public class DashboardAdminPanel extends JPanel {
    private MainFrame frame;
    private JTabbedPane tabbedPane = new JTabbedPane();
    private JTable utilisateurTable, patientTable, specialisteTable, rdvTable, historiqueTable;
    private Controleur.AdminControleur controleur = new Controleur.AdminControleur();

    public DashboardAdminPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout());
        add(buildHeaderPanel(), BorderLayout.NORTH);
        tabbedPane.addTab("UTILISATEUR", buildUtilisateurTab());
        tabbedPane.addTab("PATIENT", buildPatientTab());
        tabbedPane.addTab("SPECIALISTE", buildSpecialisteTab());
        tabbedPane.addTab("RENDEZ_VOUS", buildRdvTab());
        tabbedPane.addTab("HISTORIQUE", buildHistoriqueTab());
        add(tabbedPane, BorderLayout.CENTER);
    }

    private JPanel buildHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.add(new JLabel("Espace Administrateur - Gestion des tables BDD"), BorderLayout.WEST);
        JButton btnDeconnexion = new JButton("Déconnexion");
        btnDeconnexion.addActionListener(e -> frame.showPanel("accueil"));
        header.add(btnDeconnexion, BorderLayout.EAST);
        return header;
    }

    private JPanel buildUtilisateurTab() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columns = {"id", "nom", "prenom", "email", "mot_de_passe", "type_utilisateur"};
        Vector<Vector<Object>> data = new Vector<>();
        try {
            java.util.List<Modele.Utilisateur> utilisateurs = controleur.getAllUtilisateurs();
            for (Modele.Utilisateur u : utilisateurs) {
                Vector<Object> row = new Vector<>();
                row.add(u.getId());
                row.add(u.getNom());
                row.add(u.getPrenom());
                row.add(u.getEmail());
                row.add(u.getMotDePasse());
                row.add(u.getTypeUtilisateur());
                data.add(row);
            }
        } catch (Exception e) { }
        utilisateurTable = new JTable(new DefaultTableModel(data, new Vector<>(List.of(columns))) {
            public boolean isCellEditable(int row, int col) { return col != 0; }
        });
        utilisateurTable.putClientProperty("tableName", "UTILISATEUR");
        utilisateurTable.getModel().addTableModelListener(e -> handleEdit(utilisateurTable, columns));
        panel.add(new JScrollPane(utilisateurTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildPatientTab() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columns = {"id", "date_naissance", "adresse", "telephone"};
        Vector<Vector<Object>> data = new Vector<>();
        try {
            List<Patient> patients = controleur.getAllPatients();
            for (Patient p : patients) {
                Vector<Object> row = new Vector<>();
                row.add(p.getId());
                row.add(p.getDateNaissance());
                row.add(p.getAdresse());
                row.add(p.getTelephone());
                data.add(row);
            }
        } catch (Exception e) { }
        patientTable = new JTable(new DefaultTableModel(data, new Vector<>(List.of(columns))) {
            public boolean isCellEditable(int row, int col) { return col != 0; }
        });
        patientTable.putClientProperty("tableName", "PATIENT");
        patientTable.getModel().addTableModelListener(e -> handleEdit(patientTable, columns));
        panel.add(new JScrollPane(patientTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildSpecialisteTab() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columns = {"id", "nom", "prenom", "specialisation", "telephone", "email"};
        Vector<Vector<Object>> data = new Vector<>();
        try {
            List<Specialiste> specs = controleur.getAllSpecialistes();
            for (Specialiste s : specs) {
                Vector<Object> row = new Vector<>();
                row.add(s.getId());
                row.add(s.getNom());
                row.add(s.getPrenom());
                row.add(s.getSpecialisation());
                row.add(s.getTelephone());
                row.add(s.getEmail());
                data.add(row);
            }
        } catch (Exception e) { }
        specialisteTable = new JTable(new DefaultTableModel(data, new Vector<>(List.of(columns))) {
            public boolean isCellEditable(int row, int col) { return col != 0; }
        });
        specialisteTable.putClientProperty("tableName", "SPECIALISTE");
        specialisteTable.getModel().addTableModelListener(e -> handleEdit(specialisteTable, columns));
        panel.add(new JScrollPane(specialisteTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildRdvTab() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columns = {"id", "patient_id", "specialiste_id", "date_heure", "statut"};
        Vector<Vector<Object>> data = new Vector<>();
        try {
            List<RendezVous> rdvs = controleur.getAllRendezVous();
            for (RendezVous r : rdvs) {
                Vector<Object> row = new Vector<>();
                row.add(r.getId());
                row.add(null); // patient_id (à compléter si besoin)
                row.add(null); // specialiste_id (à compléter si besoin)
                row.add(r.getDateHeure());
                row.add(r.getStatut());
                data.add(row);
            }
        } catch (Exception e) { }
        rdvTable = new JTable(new DefaultTableModel(data, new Vector<>(List.of(columns))) {
            public boolean isCellEditable(int row, int col) { return col != 0; }
        });
        rdvTable.putClientProperty("tableName", "RENDEZ_VOUS");
        rdvTable.getModel().addTableModelListener(e -> handleEdit(rdvTable, columns));
        panel.add(new JScrollPane(rdvTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildHistoriqueTab() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columns = {"id", "patient_id", "rendez_vous_id", "notes"};
        Vector<Vector<Object>> data = new Vector<>();
        try {
            List<Historique> histos = controleur.getAllHistoriques();
            for (Historique h : histos) {
                Vector<Object> row = new Vector<>();
                row.add(h.getId());
                row.add(h.getPatientId());
                row.add(h.getRendezVousId());
                row.add(h.getNotes());
                data.add(row);
            }
        } catch (Exception e) { }
        historiqueTable = new JTable(new DefaultTableModel(data, new Vector<>(List.of(columns))) {
            public boolean isCellEditable(int row, int col) { return col != 0; }
        });
        historiqueTable.putClientProperty("tableName", "HISTORIQUE");
        historiqueTable.getModel().addTableModelListener(e -> handleEdit(historiqueTable, columns));
        panel.add(new JScrollPane(historiqueTable), BorderLayout.CENTER);
        return panel;
    }

    private void handleEdit(JTable table, String[] columns) {
        int row = table.getSelectedRow();
        int col = table.getSelectedColumn();
        if (row < 0 || col < 0) return;
        Object newValue = table.getValueAt(row, col);
        Object oldValue = ((DefaultTableModel) table.getModel()).getValueAt(row, col);
        int id = (int) table.getValueAt(row, 0);
        String colName = columns[col];
        int res = JOptionPane.showConfirmDialog(this, "Valider la modification de " + colName + " ?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                String tableName = (String) table.getClientProperty("tableName");
                switch (tableName) {
                    case "UTILISATEUR":
                        Modele.Utilisateur utilisateur = null;
                        for (Modele.Utilisateur u : controleur.getAllUtilisateurs()) {
                            if (u.getId() == id) { utilisateur = u; break; }
                        }
                        if (utilisateur != null) {
                            controleur.updateUtilisateur(utilisateur, colName, newValue);
                        }
                        break;
                    case "PATIENT":
                        // ...
                        break;
                    case "SPECIALISTE":
                        // ...
                        break;
                    case "RENDEZ_VOUS":
                        controleur.updateRendezVous(id, colName, newValue);
                        break;
                    case "HISTORIQUE":
                        controleur.updateHistorique(id, colName, newValue);
                        break;
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur lors de la modification: " + ex.getMessage());
            }
        } else {
            ((DefaultTableModel) table.getModel()).setValueAt(oldValue, row, col);
        }
    }
}
